import React from 'react'
import './footer.css'


const footer = () => {
  return (
    <div className = "footer">
        @copyright Reserved 2025
    </div>
  )
}

export default footer
